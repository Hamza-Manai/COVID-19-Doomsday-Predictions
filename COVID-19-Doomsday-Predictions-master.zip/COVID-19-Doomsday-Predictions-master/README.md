# COVID-19-Doomsday-Predictions
COVID-19, the disease that can result from the coronavirus worldwide new pandemic, is spreading across the globe. While it has a "lower" fatality rate than the last four aforementioned diseases above, it has spread to many more countries and has infected thousands more people. We try to predict for the next days how many new cases and how many victims the disease will affect.

Our predictions for 23/03/2020 : 

The predictions for Total Cases in the following 1 days is:
374118

The predictions for Total Active Cases in the following 1 days is:
252519

The predictions for Total Cured Cases in the following 1 days is:
104630

The predictions for Total Deaths in the following 1 days is:
16485

The predictions for Total Critical Cases in the following 1 days is:
12252